'use strict';

console.log('-------------- index.WP.js -----------------');
function dobleDe(a) {
  return 2 * a;
};

var num = 16

console.log('El cuádruple de ' + num + ' es ' + dobleDe(dobleDe(num)));
console.log('---------------------------------------------');
