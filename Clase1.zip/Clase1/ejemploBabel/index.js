var a = 5
var b = 8
var c = a + b
console.log(c)