import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Bienvenidos al Proyecto en React.JS</h1>
    </div>
  );
}

export default App;
