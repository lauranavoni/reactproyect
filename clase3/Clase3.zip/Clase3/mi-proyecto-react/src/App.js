import React from 'react'
import { BrowserRouter, Redirect, Route, Switch } from 'react-router-dom';

import './App.css';
import Contador from './componentes/Contador';
import Mensaje from './componentes/Mensaje';
import { Navbar } from './componentes/Navbar';
import { RutaNoValida } from './componentes/RutaNoValida';


function MostrarDatosHijo(props) {
  let { id, contador, contador2 } = props.datos//props

  if(id) return <h3 className="alert alert-success"> Datos recibidos del Contador Nro. {id}: c1[{contador}] - c2[{contador2}]</h3>
  else return <h3 className="alert alert-danger"> No hay datos del contador</h3>
}


class App extends React.Component {

  constructor() {
    super()

    this.recibirDatosHijo = this.recibirDatosHijo.bind(this)
  }
  /* recibirDatosHijo(id, contador) {
    console.log(`Datos recibidos del Contador Nro. ${id}: ${contador}`)
  } */

  state = {
    datos : { id: null, contador: null, contador2: null }
  }

  recibirDatosHijo(datos) {
    //let { id, contador, contador2 } = datos
    //console.log(`Datos recibidos del Contador Nro. ${id}: c1[${contador}] - c2[${contador2}]`)
    //this.setState({ datos: datos })
    this.setState({ datos })
  }

  render() {
    console.log('---> App render')

    //let { id, contador, contador2 } = this.state.datos

    return (
      <div className="App">
        <div className="container mt-3">
          <div className="jumbotron">
            <h1>Mi Proyecto en React.JS</h1>
            <hr />
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo officiis doloremque in. Nisi quis nesciunt enim labore. Commodi eaque nesciunt magni quisquam error! Est optio, eius sequi commodi autem quidem.
            </p>
            <hr />
            <br />

            {/* -------------------------------------------------------------------------------------- */}
            <h2><u>Router</u></h2>
            <br />

            <BrowserRouter>

              {/* ----- BARRA DE NAVEGACIÓN ---- */}
              <Navbar />
              <Switch>

                {/* Ruteado de componente para la ruta raíz */}
                {/* <Route exact path="/" component={() => <Mensaje msj="Mensaje Nro. 1" fondo="green" />} /> */}
                {/* Redirección de la ruta raíz */}
                <Route exact path="/">
                  <Redirect to="/mensaje1"/>
                </Route>

                {/* Ruteado de componentes sin parámetros */}
                <Route path="/mensaje" component={Mensaje} />

                {/* Ruteado de componentes con parámetros props */}
                <Route path="/mensaje1" component={() => <Mensaje msj="Mensaje Nro. 1" fondo="green" />} />
                <Route path="/mensaje2" component={() => <Mensaje msj="Mensaje Nro. 2" fondo="orangered" />} />
                <Route path="/mensaje3" component={() => <Mensaje msj="Mensaje Nro. 3" fondo="blueviolet" />} />

                {/* Ruteado de componentes con parámetros por ruta */}
                {/*  */}

                {/* Ruteo de Componente para ruta no váida */}
                <Route component={RutaNoValida} />

              </Switch>

            </BrowserRouter>

            {/* <div className="row">
              <div className="col-4"> <Mensaje msj="Mensaje Nro. 1" fondo="green" /> </div>
              <div className="col-4"> <Mensaje msj="Mensaje Nro. 2" fondo="orange" /> </div>
              <div className="col-4"> <Mensaje msj="Mensaje Nro. 3" fondo="blue" /> </div>
            </div>  */}         

            <hr />
            <br />

            {/* -------------------------------------------------------------------------------------- */}
            <h2><u>Up Lifting y Rendering condicional</u></h2>
            <br />

            {/* <h3 className="alert alert-success">
              Datos recibidos del Contador Nro. {id}: c1[{contador}] - c2[{contador2}]
            </h3> */}

            {/* -------------------------------------------------------------------- */}
            {/*  Render condicional usando: Operador Ternario -> cond? true : false  */}
            {/* -------------------------------------------------------------------- */}
            {/* { id?
              <h3 className="alert alert-success"> Datos recibidos del Contador Nro. {id}: c1[{contador}] - c2[{contador2}]</h3>
              :
              <h3 className="alert alert-success"> No hay datos del contador</h3>
              //<></>
            } */}
            
            {/* -------------------------------------------------------------------- */}
            {/*                Render condicional usando: Operador &&                */}
            {/* -------------------------------------------------------------------- */}
            {/* { id &&
              <h3 className="alert alert-success"> Datos recibidos del Contador Nro. {id}: c1[{contador}] - c2[{contador2}]</h3>
            }
            { !id &&
              <h3 className="alert alert-success"> No hay datos del contador</h3>
            } */}

            {/* -------------------------------------------------------------------- */}
            {/*        Render condicional usando: dentro de un componente            */}
            {/* -------------------------------------------------------------------- */}
            {/* <MostrarDatosHijo id={id} contador={contador} contador2={contador2}/> */}
            <MostrarDatosHijo datos={this.state.datos}/>


            <Contador id="1" fondo="brown" valor1="456" valor2="789" enviarContadorAlPadre={this.recibirDatosHijo} />
            <Contador id="2" fondo="black" valor1={789} valor2={321} enviarContadorAlPadre={this.recibirDatosHijo}/>

          </div>
        </div>
      </div>
    );
  }
}

export default App;
