import { NavLink } from "react-router-dom"

export const Navbar = () => 
    <nav className="navbar navbar-expand-md navbar-dark bg-info">
        <NavLink className="navbar-brand" to="/">Inicio</NavLink>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
                <li className="nav-item">
                    <NavLink className="nav-link" to="/mensaje">Mensaje</NavLink>
                </li>

                <li className="nav-item">
                    <NavLink className="nav-link" to="/mensaje1">Mensaje 1</NavLink>
                </li>

                <li className="nav-item">
                    <NavLink className="nav-link" to="/mensaje2">Mensaje 2</NavLink>
                </li>

                <li className="nav-item">
                    <NavLink className="nav-link" to="/mensaje3">Mensaje 3</NavLink>
                </li>
            </ul>
        </div>
    </nav>

/*
export const Navbar = () => {
    return (
        <nav className="navbar navbar-expand-md navbar-dark bg-info">
            <NavLink className="navbar-brand" to="/">Inicio</NavLink>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav">
                    <li className="nav-item">
                        <NavLink className="nav-link" to="/mensaje">Mensaje</NavLink>
                    </li>

                    <li className="nav-item">
                        <NavLink className="nav-link" to="/mensaje1">Mensaje 1</NavLink>
                    </li>

                    <li className="nav-item">
                        <NavLink className="nav-link" to="/mensaje2">Mensaje 2</NavLink>
                    </li>

                    <li className="nav-item">
                        <NavLink className="nav-link" to="/mensaje3">Mensaje 3</NavLink>
                    </li>
                </ul>
            </div>
        </nav>
    )
}
*/
