import './Mensaje.css'

/* ----------------------------------------------------------------------- */
/*  Componente React basado en una función (no guarda estado -> stateless) */
/* ----------------------------------------------------------------------- */
//export function Mensaje(props) {
    
//function Mensaje(props) {             //JS5
//const Mensaje = function(props) {     //JS5
const Mensaje = props => {              //ES6
    //let msj = 'Mensaje Nro. 1'
    //let fondo = 'crimson'

    /* let msj = props.msj 
    let fondo = props.fondo */
    let { msj,fondo } = props   //destructuring object (ECMAScript)
    //let contador = 0

    return (
        <div className="Mensaje">
            <div className="jumbotron" style={{backgroundColor: fondo}}>
                <h3>{msj}</h3>
                {/* {4+3} */}
                {/* {new Date().toLocaleString()} */}
                {/* { Date.now() } */}
                {/* { Math.random() } */}
                {/* { ++contador } */}
                <hr />
                <p>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. In nisi, eos quod eligendi fugit blanditiis, veritatis atque possimus voluptates sint laborum dolor neque ipsa consequuntur corporis? Totam voluptate reiciendis doloremque.
                </p>
            </div>
        </div>
    )
}

export default Mensaje
/*
export {
    Mensaje
}
*/