import React from 'react'
import './Contador.css'

/* ----------------------------------------------------------------------- */
/*    Componente React basado en una clase (guarda estado -> statefull)    */
/* ----------------------------------------------------------------------- */
class Contador extends React.Component {

    constructor(props) {
        super(props)
        console.log('--------------------------')
        console.log(`Contador ${props.id} constructor`)
    }

    state = {
        contador: Number(this.props.valor1),
        contador2: Number(this.props.valor2)
    }

    enviarDatosAlPadre() {
        //console.log(`Contador ${id}`, this.state.contador) //estado actualizado 
        let { contador, contador2 } = this.state
        let { id, enviarContadorAlPadre } = this.props
        let datos = {
            id, //  es igual a -> id: id,
            contador,// es igual a -> contador: contador
            contador2
        }
        enviarContadorAlPadre(datos)
    }

    /*
    incrementar1() {
        //let { id } = this.props
        console.log('--------------------------')
        //console.log(`Contador ${id} Incrementar`)
        this.setState( prevstate => ({contador: prevstate.contador + 1}), this.enviarDatosAlPadre )
    }

    incrementar2() {
        //let { id } = this.props
        console.log('--------------------------')
        //console.log(`Contador ${id} Incrementar`)
        this.setState( prevstate => ({contador2: prevstate.contador2 + 1}), this.enviarDatosAlPadre )
    }
    */
    incrementar(numero) {
        //let { id } = this.props
        console.log('--------------------------')
        //console.log(`Contador ${id} Incrementar`)
        if(numero === 1)
            this.setState( prevstate => ({contador: prevstate.contador + 1}), this.enviarDatosAlPadre )
        else if(numero === 2)
            this.setState( prevstate => ({contador2: prevstate.contador2 + 1}), this.enviarDatosAlPadre )
    }


    render() {
        let { id,fondo } = this.props
        let { contador,contador2 } = this.state
        //console.log(`Contador ${id} render`)

        return (
            <div className="Contador">
                <div className="jumbotron" style={{backgroundColor: fondo}}>
                    <h3>Contador Nro. {id}</h3>
                    <hr />
                    
                    {/* ------------------------------------------- */}
                    {/*                  Contador 1                 */}
                    {/* ------------------------------------------- */}
                    <h4 className="alert alert-info w-100">Contador: {contador}</h4>
                    {/* <button className="btn btn-success mb-3" onClick={() => this.incrementar1()}>Incrementar</button> */}
                    <button className="btn btn-success mb-3" onClick={() => this.incrementar(1)}>Incrementar</button>
                    
                    {/* ------------------------------------------- */}
                    {/*                  Contador 2                 */}
                    {/* ------------------------------------------- */}
                    <h4 className="alert alert-info w-100">Contador2: {contador2}</h4>
                    {/* <button className="btn btn-success" onClick={() => this.incrementar2()}>Incrementar2</button> */}
                    <button className="btn btn-success" onClick={() => this.incrementar(2)}>Incrementar2</button>

                </div>
            </div>
        )
    }
}

export default Contador

