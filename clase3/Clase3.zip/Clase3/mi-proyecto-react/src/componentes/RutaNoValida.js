import './RutaNoValida.css'
/*
export const RutaNoValida = () => {
    return (
        <div className="RutaNoValida">
            <div className="jumbotron">
                <h1>Ruta no válida!</h1>
            </div>
        </div>
    )
}
*/
export const RutaNoValida = () => 
    <div className="RutaNoValida">
        <div className="jumbotron">
            <h1>Ruta no válida!</h1>
        </div>
    </div>
